import{_ as o}from"./KoiRightChart.vue_vue_type_script_setup_true_lang-CyQvqC7Q.js";import"./index-CIGBWQpf.js";import"./index-DpLe_dtH.js";export{o as default};
