import{_ as e,c,e as s}from"./index-DpLe_dtH.js";const t={},n={class:"p-4px"};function o(r,_){return s(),c("div",n,"工作台")}const d=e(t,[["render",o]]);export{d as default};
