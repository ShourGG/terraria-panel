import{_ as m}from"./KoiTimeline2.vue_vue_type_script_setup_true_lang-CG5V2cYP.js";import"./index-DpLe_dtH.js";export{m as default};
