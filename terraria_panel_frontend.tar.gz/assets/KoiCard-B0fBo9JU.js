import{_ as m}from"./KoiCard.vue_vue_type_script_setup_true_lang-Dr2OQjW5.js";import"./index-DpLe_dtH.js";export{m as default};
