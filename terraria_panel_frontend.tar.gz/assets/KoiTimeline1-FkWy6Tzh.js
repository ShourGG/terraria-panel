import{_ as m}from"./KoiTimeline1.vue_vue_type_script_setup_true_lang-ZgipYw3v.js";import"./index-DpLe_dtH.js";export{m as default};
